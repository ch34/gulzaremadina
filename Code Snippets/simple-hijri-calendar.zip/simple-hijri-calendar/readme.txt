=== Simple Hijri Calendar ===
Contributors: dakwahstudiodotcom, tompradana
Donate link: http://dakwahstudio.com/projek/simple-hijri-calendar/
Tags: hijri, calendar, arabic calendar
Requires at least: 3.9
Tested up to: 4.6.1
Stable tag: 4.6.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Very simple hijri calendar widget plugin.

== Description ==

"Simple Hijri Calendar" is a very simple, light and easy to use wordpress plugin that allows you to show curent hijri date. Just instal and active plugin. Then drag and drop "Simple Hijri Calendar" widget in your widget area!.

= Features =

* Date format
* Arabic or English text
* Google arabic font
* Translation ready
* Easy to style
* Time based background image

= credits =

* http://aziz.oraij.com/
* http://www.phpclasses.org/contact/package/6626.html

== Installation ==

The quickest method for installing the importer is:

1. Visit Tools -> Import in the WordPress dashboard
1. Click on the WordPress link in the list of importers
1. Click "Install Now"
1. Finally click "Activate Plugin & Add Widget"

If you would prefer to do things manually then follow these instructions:

1. Upload the "simple-hijri-calendar" folder to the "/wp-content/plugins/" directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to the Appearence -> Widget screen, then drag and drop "Simple Hijri Calendar" widget in your widget area

== Frequently Asked Questions ==

= Questions =

none

== Screenshots ==

1. Simple Hijri Calendar widget

== Changelog ==

= 2.1.2 =
* fix broken link

= 2.1.1 =
* fix css error issue

= 2.0 =
* All new.

= 1.0 =
* Initial release.

== Upgrade Notice ==

none
